<?php $__env->startSection('title', 'Tin tức theo danh mục'); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="container my-5">
    <!-- Latest News -->
    <h3 class="mb-4 border-bottom pb-2">Tên danh mục</h3>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__currentLoopData = $newsCates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $News): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <a href="<?php echo e(route('newsDetail',['id' => $News->id])); ?>" class="text-decoration-none">
                    <div class="card h-100 news-card">
                        <span class="badge bg-danger category-badge">NEW</span>
                        <img src="<?php echo e($News->image); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($News->title); ?></h5>
                            <p class="card-text"><?php echo e($News->description_short); ?>...</p>
                            <div class="post-meta">
                                <small><i class="fas fa-eye"></i><?php echo e($News->views); ?> lượt xem</small>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap_trinh_php_3\LAB\assignment_php3\resources\views/newsCategory.blade.php ENDPATH**/ ?>