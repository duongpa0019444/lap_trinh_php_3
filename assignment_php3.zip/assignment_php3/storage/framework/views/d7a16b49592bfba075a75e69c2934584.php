<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\lap_trinh_php_3\LAB\assignment_php3\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>