<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang chi tiết tin tức - NEWS24</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }

        .featured-post {
            height: 400px;
            object-fit: cover;
        }

        .news-card {
            transition: transform 0.3s;
        }

        .news-card:hover {
            transform: translateY(-5px);
        }

        .category-badge {
            position: absolute;
            top: 10px;
            left: 10px;
            z-index: 2;
        }

        .post-meta {
            font-size: 0.9rem;
            color: #6c757d;
        }

        .sticky-nav {
            position: sticky;
            top: 0;
            z-index: 1020;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-nav">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">NEWS24</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('home')); ?>">Trang chủ</a>
                    </li>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('newsCate', ['id' => $category->id])); ?>">
                            <?php echo e($category->name); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Tìm kiếm">
                    <button class="btn btn-outline-light" type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>
        </div>
    </nav>


    <!-- Main Content -->
    <div class="container my-5">
        <div class="row">
            <!-- Chi tiết bài viết -->
            <div class="col-md-8">
                <article class="news-detail">
                    <h2 class="mb-4"><?php echo e($newsDetail->title); ?></h2>
                    <div class="author-info">

                        <div>
                            <p>
                                <?php echo e($newsDetail->description_short); ?>

                            </p>
                            <small class="text-muted"><?php echo e($newsDetail->created_at); ?></small>
                        </div>
                    </div>
                    <img src="<?php echo e($newsDetail->image); ?>" class="img-fluid w-100 mb-4" alt="Tiêu đề bài viết">
                    <div class="content">

                        <p>
                            <?php echo e($newsDetail->description); ?>

                    </div>
                </article>
            </div>

            <!-- Bài viết liên quan -->
            <div class="col-md-4">
                <h3 class="mb-4">Bài viết liên quan</h3>
                <div class="card mb-3">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="Bài viết liên quan 1">
                    <div class="card-body">
                        <h5 class="card-title">Tiêu đề bài viết liên quan 1</h5>
                        <a href="#" class="btn btn-primary">Xem chi tiết</a>
                    </div>
                </div>
                <div class="card mb-3">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="Bài viết liên quan 2">
                    <div class="card-body">
                        <h5 class="card-title">Tiêu đề bài viết liên quan 2</h5>
                        <a href="#" class="btn btn-primary">Xem chi tiết</a>
                    </div>
                </div>
                <div class="card mb-3">
                    <img src="https://via.placeholder.com/300x150" class="card-img-top" alt="Bài viết liên quan 3">
                    <div class="card-body">
                        <h5 class="card-title">Tiêu đề bài viết liên quan 3</h5>
                        <a href="#" class="btn btn-primary">Xem chi tiết</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; 2023 NEWS24. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-end">
                    <a href="#" class="text-white me-3"><i class="fab fa-facebook"></i></a>
                    <a href="#" class="text-white me-3"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-white"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lap_trinh_php_3\LAB\Lab2\resources\views/newsDetail.blade.php ENDPATH**/ ?>