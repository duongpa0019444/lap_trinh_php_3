<?php $__env->startSection('title', 'Trang chủ tin tức của NEWS'); ?>

<?php $__env->startSection('content'); ?>
<div class="container account-container d-flex">
    <!-- Sidebar -->
    <div class="col-md-4 sidebar">
        <div class="text-center mb-3">
            <img src="<?php echo e(asset('img/banthan2.jpg')); ?>" alt="Avatar" class="avatar">
            <h5 class="mt-2"><?php echo e($user->name); ?></h5>
        </div>
        <a href="#" class="menu-item active" data-target="#profile">Thông tin cá nhân</a>
        <a href="#" class="menu-item" data-target="#password">Đổi mật khẩu</a>
        <a href="<?php echo e(route('logout')); ?>">Đăng xuất</a>
    </div>

    <!-- Content -->
    <div class="col-md-8 p-3">
        <div id="profile" class="content active">
            <h3>Thông tin cá nhân</h3>
            <p>Họ Tên: <?php echo e($user->name); ?></p>
            <p>Email: <?php echo e($user->email); ?></p>

        </div>
        <div id="password" class="content">
            <h3>Đổi mật khẩu</h3>
            <form>
                <div class="mb-3">
                    <label>Mật khẩu cũ</label>
                    <input type="password" class="form-control">
                </div>
                <div class="mb-3">
                    <label>Mật khẩu mới</label>
                    <input type="password" class="form-control">
                </div>
                <button class="btn btn-primary">Cập nhật</button>
            </form>
        </div>

    </div>
</div>
<script>


//my account
$(document).ready(function() {
    $(".menu-item").click(function(e) {
        e.preventDefault();
        $(".menu-item").removeClass("active");
        $(this).addClass("active");
        $(".content").removeClass("active");
        $($(this).data("target")).addClass("active");
    });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap_trinh_php_3\LAB\assignment_php3\resources\views/myaccount.blade.php ENDPATH**/ ?>