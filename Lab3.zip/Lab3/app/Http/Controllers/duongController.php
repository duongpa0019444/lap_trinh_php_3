<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class duongController extends Controller
{
    //
    public function information(){
        return view('information');
    }
}
