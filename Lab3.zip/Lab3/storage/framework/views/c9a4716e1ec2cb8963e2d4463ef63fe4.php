<?php $__env->startSection('title'); ?>
    Trang thông tin của tôi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>
    body {
        background-color: #f8f9fa;
    }
    .profile-card {
        background: #fff;
        border-radius: 10px;
        padding: 30px;
        text-align: center;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    }
    .profile-img {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        margin-bottom: 20px;
        object-fit: cover;
        object-position: top;
    }
    .social-icons a {
        margin: 0 10px;
        font-size: 20px;
        color: #007bff;
        transition: 0.3s;
    }
    .social-icons a:hover {
        color: #0056b3;
    }
</style>
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="profile-card">
            <img src="<?php echo e(asset('img/banthan2.jpg')); ?>" alt="Avatar" class="profile-img">
            <h3>ĐÀO TÙNG DƯƠNG</h3>
            <p class="text-muted">Web Developer</p>
            <p>Chào mừng đến với trang cá nhân của tôi! Tôi là một lập trình viên đam mê công nghệ và sáng tạo.</p>
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
            </div>
            <button class="btn btn-primary mt-3">Liên hệ</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap_trinh_php_3\LAB\Lab3\resources\views/information.blade.php ENDPATH**/ ?>