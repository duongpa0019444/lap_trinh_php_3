<?php $__env->startSection('title'); ?>
    <?php echo e($newsdetail->title); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Chi tiết tin tức</h1>  <hr>
<div class="container mt-4">
    <div class="row">
        <div class="col-lg-8">
            <h1 class="mb-3"><?php echo e($newsdetail->title); ?></h1>
            <p class="text-muted">Đăng bởi <strong>Tác giả</strong> - Ngày đăng:  <?php echo e($newsdetail->created_at); ?></p>
            <img src="<?php echo e($newsdetail->image); ?>" class="img-fluid rounded mb-4 w-100" alt="Ảnh bài viết">
            <p class="lead"> <?php echo e($newsdetail->description_short); ?></p>
            <p><?php echo e($newsdetail->description); ?></p>
        </div>

        <!-- Sidebar: Bài viết liên quan -->
        <div class="col-lg-4">
            <h4 class="mb-3">Bài viết liên quan</h4>
            <ul class="list-group">
                <li class="list-group-item"><a href="#">Tin tức 1</a></li>
                <li class="list-group-item"><a href="#">Tin tức 2</a></li>
                <li class="list-group-item"><a href="#">Tin tức 3</a></li>
                <li class="list-group-item"><a href="#">Tin tức 4</a></li>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap_trinh_php_3\LAB\Lab3\resources\views/chitiet.blade.php ENDPATH**/ ?>