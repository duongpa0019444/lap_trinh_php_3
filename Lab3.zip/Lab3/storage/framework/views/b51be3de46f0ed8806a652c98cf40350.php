<?php $__env->startSection('title'); ?>
    Tin trong loại <?php echo e($idcategory); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Đây là trang tin trong loại <?php echo e($idcategory); ?></h1>
<div class="row">
    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-4">
        <a href="/ct/<?php echo e($item->id); ?>" class="card" style="width: 18rem;">
            <img src="<?php echo e($item->image); ?>" class="card-img-top" alt="">
            <div class="card-body">
            <h5 class="card-title"><?php echo e($item->title); ?></h5>
            </div>
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\lap_trinh_php_3\LAB\Lab3\resources\views/tintrongloai.blade.php ENDPATH**/ ?>