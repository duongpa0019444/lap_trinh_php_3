<p>Chào bạn <?=Auth::user()->name?> </p>
Đây là trang download software, chỉ dành cho thành viên đăng nhập
<p><a href="thoat">Thóat</a></p>
<?php /**PATH C:\xampp\htdocs\lap_trinh_php_3\LAB\Lab6\resources\views/download.blade.php ENDPATH**/ ?>