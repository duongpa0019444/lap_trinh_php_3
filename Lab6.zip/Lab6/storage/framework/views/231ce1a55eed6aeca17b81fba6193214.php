<h1>Chào bạn <?php echo e(Auth::user()->name); ?></h1>

ĐÂY LÀ TRANG QUẢN TRỊ DÀNH CHO ADMIN
<?php /**PATH C:\xampp\htdocs\lap_trinh_php_3\LAB\Lab6\resources\views/quantri.blade.php ENDPATH**/ ?>