<h1>Chào bạn {{Auth::user()->name}}</h1>

ĐÂY LÀ TRANG QUẢN TRỊ DÀNH CHO ADMIN
