<p>Chào bạn <?=Auth::user()->name?> </p>
Đây là trang download software, chỉ dành cho thành viên đăng nhập
<p><a href="thoat">Thóat</a></p>
