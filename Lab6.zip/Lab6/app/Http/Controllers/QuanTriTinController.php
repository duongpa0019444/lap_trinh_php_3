<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class QuanTriTinController extends Controller
{
    public function index(){
        echo '<h1>Danh sách tin</h1>'
    }
}
