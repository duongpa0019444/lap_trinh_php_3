<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<div class="container">
    <h2 class="mb-3">Danh Sách Tin Tức</h2>
    <a href="<?php echo e(route('tin.them')); ?>"><button class="btn btn-success">Thêm</button></a>
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert"><?php echo e(Session::get('success')); ?></div>
    <?php endif; ?>
    <table class="table table-striped table-bordered">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Tiêu Đề</th>
                <th>Hình Ảnh</th>
                <th>Ngày Đăng</th>
                <th>Nội Dung</th>
                <th>Lượt Xem</th>
                <th>Hành Động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($tin->tieuDe); ?></td>
                    <td>
                        
                        <img src="<?php echo e(Storage::url($tin->urlHinh)); ?>" alt="Hình ảnh" class="img-thumbnail" style="width: 100px;">
                    </td>
                    <td><?php echo e(\Carbon\Carbon::parse($tin->ngayDang)->format('d-m-Y')); ?></td>
                    <td><?php echo e(Str::limit($tin->noiDung, 50)); ?></td>
                    <td><?php echo e(number_format($tin->xem)); ?></td>
                    <td>
                        <a href="<?php echo e(route('tin.edit',$tin->id)); ?>" class="btn btn-sm btn-primary">Sửa</a>
                        <form action="<?php echo e(route('tin.delete')); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="hidden" name="id" value="<?php echo e($tin->id); ?>">
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa?');">Xóa</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\lap_trinh_php_3\LAB\Lab5\resources\views/Tin/danhsach.blade.php ENDPATH**/ ?>